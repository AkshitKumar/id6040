The submission to the assignment contains three parts:
1. The PDF which contains the solution to Question 1 and Question 2. It also contains the source code for Question 3.
2. The Python Source Code named calculateTransformation.py for the Question 3.
3. Input File named dh_parameters.csv containing the DH Parameters for a PUMA robot.

The following are the dependencies for running the Python Program:
numpy
pandas

The program has been tested on MacOS and Linux Operating Systems. In case of errors while trying out on Windows, please contact the creator at akshitkumar100@gmail.com